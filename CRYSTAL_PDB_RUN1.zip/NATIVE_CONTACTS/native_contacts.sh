#!/bin/bash

TOPO=6mdx_sol.prmtop
TRAJ1=mdcrd.prod1

echo "Running cpptraj analysis for CRYSTAL..."

cpptraj <<EOF
parm $TOPO

# Load BOTH trajectories
trajin $TRAJ1

autoimage
rms first @CA

################################################
# SALT BRIDGES (Distance-based)
################################################

distance SB_CCD_A_B \
:1-139@OD1,OD2,OE1,OE2 \
:140-187@NZ,NH1,NH2 \
out SB_crystal.dat


################################################
# HYDROPHOBIC CONTACTS
################################################

nativecontacts name hyd_CCD_A_B \
(:1-139&:ALA,VAL,LEU,ILE,MET,PHE,TRP,PRO) \
(:140-187&:ALA,VAL,LEU,ILE,MET,PHE,TRP,PRO) \
distance 4.5 \
resout hyd_crystal.dat \
out hyd_crystal_total.dat

run
EOF

echo ""
echo "Calculating salt bridge occupancy..."

##############################################
# SALT BRIDGE OCCUPANCY
##############################################

> EOF

echo ""
echo "Calculating salt bridge occupancy..."

##############################################
# SALT BRIDGE OCCUPANCY
##############################################

> SALT_MONOMER.dat

for file in SB_*.dat
do
awk '
NR>1 {
    total++
    if ($2 < 4.0) count++
}
END {
    if (total > 0)
        printf "%s  %.2f%%\n", FILENAME, (count/total)*100
    else
        printf "%s  0.00%%\n", FILENAME
}' $file >> SALT_MONOMER.dat
done

##############################################
# HYDROPHOBIC FILTER (>10%)
##############################################

> HYDRO_MONOMER_gt10.dat

for file in hyd_*_res.dat
do
awk '
NR>1 && $3 > 10 {
printf "%s  %s  %s  %.2f%%\n", FILENAME, $1, $2, $3
}' $file >> HYDRO_MONOMER_gt10.dat
done

##############################################
# FINAL SUMMARY
##############################################

echo "HIV-1 Integrase Monomer Contacts" > FINAL_MONOMER_CONTACTS.txt
echo "====================================" >> FINAL_MONOMER_CONTACTS.txt

echo "" >> FINAL_MONOMER_CONTACTS.txt
echo "---- SALT BRIDGES (% occupancy) ----" >> FINAL_MONOMER_CONTACTS.txt
cat SALT_MONOMER.dat >> FINAL_MONOMER_CONTACTS.txt

echo "" >> FINAL_MONOMER_CONTACTS.txt
echo "---- HYDROPHOBIC CONTACTS (>10%) ----" >> FINAL_MONOMER_CONTACTS.txt
cat HYDRO_MONOMER_gt10.dat >> FINAL_MONOMER_CONTACTS.txt

echo "Done."
echo "Results saved in FINAL_MONOMER_CONTACTS.txt"


for file in SB_*.dat
do
awk '
NR>1 {
    total++
    if ($2 < 4.0) count++
}
END {
    if (total > 0)
        printf "%s  %.2f%%\n", FILENAME, (count/total)*100
    else
        printf "%s  0.00%%\n", FILENAME
}' $file >> SALT_MONOMER.dat
done

##############################################
# HYDROPHOBIC FILTER (>10%)
##############################################

> HYDRO_MONOMER_gt10.dat

for file in hyd_*_res.dat
do
awk '
NR>1 && $3 > 10 {
printf "%s  %s  %s  %.2f%%\n", FILENAME, $1, $2, $3
}' $file >> HYDRO_MONOMER_gt10.dat
done

##############################################
# FINAL SUMMARY
##############################################

echo "HIV-1 Integrase Monomer Contacts" > FINAL_MONOMER_CONTACTS.txt
echo "====================================" >> FINAL_MONOMER_CONTACTS.txt

echo "" >> FINAL_MONOMER_CONTACTS.txt
echo "---- SALT BRIDGES (% occupancy) ----" >> FINAL_MONOMER_CONTACTS.txt
cat SALT_MONOMER.dat >> FINAL_MONOMER_CONTACTS.txt

echo "" >> FINAL_MONOMER_CONTACTS.txt
echo "---- HYDROPHOBIC CONTACTS (>10%) ----" >> FINAL_MONOMER_CONTACTS.txt
cat HYDRO_MONOMER_gt10.dat >> FINAL_MONOMER_CONTACTS.txt

echo "Done."
echo "Results saved in FINAL_MONOMER_CONTACTS.txt"


