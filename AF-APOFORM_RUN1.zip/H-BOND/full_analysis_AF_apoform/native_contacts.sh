#!/bin/bash

TOPO=AF_sol.prmtop
TRAJ=mdcrd.prod1

echo "=========================================="
echo "Running full domain interface analysis"
echo "=========================================="

cpptraj <<EOF

parm $TOPO
trajin $TRAJ

############################################################
# TRAJECTORY PROCESSING
############################################################

autoimage

# Remove overall translational/rotational motion
rms first @CA

############################################################
# 1. DOMAIN-DOMAIN MINIMUM DISTANCE
############################################################

distance DOM_distance \
:1-139 :140-187 \
out domain_distance.dat

############################################################
# 2. DOMAIN-DOMAIN HYDROGEN BONDS
############################################################

hbond HB_DOM \
donormask :1-139 \
acceptormask :140-187 \
dist 3.5 \
angle 135 \
out HB_total.dat \
avgout HB_avg.dat \
nointramol

############################################################
# 3. DOMAIN-DOMAIN SALT BRIDGES
############################################################

nativecontacts name SB_DOM \
(:1-139)&(:ASP,GLU@OD1,OD2,OE1,OE2) \
(:140-187)&(:LYS,ARG@NZ,NH1,NH2) \
distance 4.0 \
resout SB_residue.dat \
out SB_total.dat

############################################################
# 4. HYDROPHOBIC CONTACTS
############################################################

nativecontacts name HYDRO_DOM \
(:1-139)&(:ALA,VAL,LEU,ILE,MET,PHE,TRP,PRO) \
(:140-187)&(:ALA,VAL,LEU,ILE,MET,PHE,TRP,PRO) \
distance 4.5 \
resout HYDRO_residue.dat \
out HYDRO_total.dat

############################################################
# 5. TOTAL HEAVY-ATOM CONTACTS
############################################################

nativecontacts name TOTAL_DOM \
(:1-139)&!@H* \
(:140-187)&!@H* \
distance 4.5 \
out TOTAL_total.dat

run

############################################################
# WRITE PROCESSED TRAJECTORY
############################################################

trajout processed_interface.nc netcdf

EOF

echo "=========================================="
echo "Analysis completed"
echo "=========================================="
