#!/bin/bash

TOPO=SPRTN_sol.prmtop
TRAJ=mdcrd.prod1

echo "Running full domain interface analysis..."

cpptraj <<EOF
parm $TOPO
trajin $TRAJ

autoimage
rms first @CA

############################################################
# 1️⃣ DOMAIN–DOMAIN MINIMUM DISTANCE
############################################################

distance DOM_distance \
:1-139 :140-188 \
out domain_distance.dat

############################################################
# 2️⃣ HYDROGEN BONDS
############################################################

hbond HB_DOM \
donormask :1-139 \
acceptormask :140-188 \
distance 3.5 angle 135 \
out HB_total.dat \
avgout HB_avg.dat

############################################################
# 3️⃣ SALT BRIDGES
############################################################

nativecontacts name SB_DOM \
(:1-139&:ASP,GLU@OD1,OD2,OE1,OE2) \
(:140-188&:LYS,ARG@NZ,NH1,NH2) \
distance 4.0 \
resout SB_residue.dat \
out SB_total.dat

############################################################
# 4️⃣ HYDROPHOBIC CONTACTS
############################################################

nativecontacts name HYDRO_DOM \
(:1-139&:ALA,VAL,LEU,ILE,MET,PHE,TRP,PRO) \
(:140-188&:ALA,VAL,LEU,ILE,MET,PHE,TRP,PRO) \
distance 4.5 \
resout HYDRO_residue.dat \
out HYDRO_total.dat

############################################################
# 5️⃣ TOTAL HEAVY ATOM CONTACTS
############################################################

nativecontacts name TOTAL_DOM \
(:1-139&!@H=) \
(:140-188&!@H=) \
distance 4.5 \
out TOTAL_total.dat

run
EOF

