MMPBSA.py -O -i mmpbsa.in -o mmpbsa.dat -sp complex_sol.prmtop -cp complex_gas.prmtop -rp SPRTN_gas.prmtop -lp ubiquitin_gas.prmtop -y prod1.nc 

